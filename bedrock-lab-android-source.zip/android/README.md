# Bedrock Lab para Android

Proyecto Android inicial para generar un APK instalable. La app abre el catálogo de Bedrock Lab en una pestaña y usa DownloadManager de Android para gestionar descargas en otra. Al tocar un archivo completo, lanza el selector de aplicaciones de Android (ACTION_VIEW) para que el sistema ofrezca las apps instaladas que declaran admitir ese tipo de archivo.

## Generar el APK automáticamente

El workflow `.github/workflows/android-apk.yml` compila el APK debug cuando se actualiza este proyecto, y también puede iniciarse manualmente desde GitHub Actions. Descarga `Bedrock-Lab-APK` en la sección Artifacts de la ejecución; el archivo `app-debug.apk` sirve para instalar en un dispositivo Android.

## Importación y compatibilidad

Android decide qué aplicaciones aparecen según los filtros de archivos declarados por cada app. La app no puede obligar a aparecer a clientes Minecraft que no se registren para abrir `.mcpack`, `.mcaddon` o `.mcworld`. Se debe probar en los dispositivos y variantes concretos antes de distribuir.

Este es un APK debug de prueba, no una publicación firmada de Play Store.
