# Bedrock Lab Android

Android 6.0+ (minSdk 23), target Android 16 / API 36. The current project is a testing build; it is not a new GitHub Release.

## Included in the next test APK

- Bedrock Lab web catalogue and dedicated downloads screen.
- Each row updates progress without rebuilding the list. Completed files can be imported, saved with Android's document picker, or shared. Failed downloads show a reason and offer retry/remove.
- Offline/server-error panel with retry, short transitions between tabs, and a clearer active-tab state.
- If Android has no registered app for a pack file, a short explanation offers saving it to a user-selected location for manual import.

## Test build

The repository GitHub Actions workflow creates a debug APK artifact. It does not publish a Release. Download the artifact from the completed Actions run and extract `app-debug.apk`.

## Signing before a real production release

Do not use the CI-generated debug signature for a production release. A permanent signing key must be generated and stored privately (never committed), provided to CI through encrypted repository secrets, and backed up by the owner. Future updates must use that exact keystore/key. The previous v1.1.0 APK was debug-signed with the CI runner's key, so installing this test build over it may be rejected; export the downloaded packs first and uninstall the old test build if Android requires it.

Android only offers installed apps that claim the corresponding file types. Compatibility with every unofficial Minecraft variant is not guaranteed. Verify the build and import/download flow on the user's phone before calling the app final.
