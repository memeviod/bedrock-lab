package com.memeviod.bedrocklab

import android.app.DownloadManager
import android.app.AlertDialog
import android.os.Message
import android.content.ClipData
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.appcompat.widget.AppCompatButton
import android.widget.ProgressBar
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.URLDecoder
import java.util.Locale
import java.net.URL
import java.util.concurrent.Executors
import android.util.LruCache

class MainActivity : AppCompatActivity() {
    private val dark = Color.rgb(16, 23, 15)
    private val panel = Color.rgb(26, 38, 26)
    private val lime = Color.rgb(185, 244, 107)
    private val pale = Color.rgb(244, 248, 239)
    private lateinit var web: WebView
    private lateinit var downloadsPage: LinearLayout
    private lateinit var downloadList: LinearLayout
    private lateinit var emptyDownloads: TextView
    private lateinit var offlinePage: LinearLayout
    private val rowViews = mutableMapOf<Long, DownloadRowViews>()
    private var pendingSaveId: Long? = null
    private lateinit var catalogTab: LinearLayout
    private lateinit var downloadsTab: LinearLayout
    private var showingDownloads = false
    private var catalogUnavailable = false
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val imageCache = LruCache<String, Bitmap>(10 * 1024 * 1024)
    private var pendingPackTitle = ""
    private var pendingPackImage = ""
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            if (showingDownloads) updateDownloads()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        pendingPackTitle = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PENDING_TITLE, "").orEmpty()
        pendingPackImage = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PENDING_IMAGE, "").orEmpty()
        buildUi()
        web.loadUrl(HOME)
        handler.post(refreshTask)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
        }
        web = WebView(this).apply {
            // Install before the first navigation: Android exposes JS bridges on the next document load.
            // This bridge only stores the selected catalogue item's title and thumbnail URL.
            addJavascriptInterface(downloadMetaBridge, "BedrockLabNative")
            setBackgroundColor(dark)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.userAgentString = settings.userAgentString + " BedrockLabAndroid/1.0"
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    if (requestIsCatalog(url)) catalogUnavailable = false
                    super.onPageStarted(view, url, favicon)
                }

                override fun onReceivedError(view: WebView, request: android.webkit.WebResourceRequest, error: android.webkit.WebResourceError) {
                    super.onReceivedError(view, request, error)
                    if (request.isForMainFrame && !showingDownloads && requestIsCatalog(request.url.toString())) {
                        catalogUnavailable = true
                        runOnUiThread { transitionTo(offlinePage, web, downloadsPage) }
                    }
                }

                override fun onReceivedHttpError(view: WebView, request: android.webkit.WebResourceRequest, response: android.webkit.WebResourceResponse) {
                    super.onReceivedHttpError(view, request, response)
                    if (request.isForMainFrame && response.statusCode >= 500 && !showingDownloads && requestIsCatalog(request.url.toString())) {
                        catalogUnavailable = true
                        runOnUiThread { transitionTo(offlinePage, web, downloadsPage) }
                    }
                }

                override fun onPageFinished(view: WebView, url: String) {
                    if (Uri.parse(url).host != "bedrock-lab-memeviod.onrender.com") return
                    if (!showingDownloads && !catalogUnavailable) transitionTo(web, offlinePage, downloadsPage)
                    val script = """
                        (function(){
                          if(window.__bedrockDownloadMetaInstalled)return;
                          window.__bedrockDownloadMetaInstalled=true;
                          function record(a){
                            try {
                              var card=a.closest('.card'), title='', image='';
                              if(card){title=(card.querySelector('h3')||{}).innerText||''; image=(card.querySelector('img')||{}).src||'';}
                              if(!title){title=(document.querySelector('#detailTitle')||{}).innerText||document.title||'';}
                              if(window.BedrockLabNative)window.BedrockLabNative.recordDownloadMeta(a.href,title,image);
                            }catch(e){}
                          }
                          document.addEventListener('click',function(e){
                            var detail=e.target.closest('[data-detail]');
                            if(detail){var c=detail.closest('.card');if(c){var a=c.querySelector('a[href]');if(a)record(a);}}
                            var da=e.target.closest('#detailAction a');if(da){var title=(document.querySelector('#detailTitle')||{}).innerText||'';var image=(document.querySelector('#detailGallery img')||{}).src||'';if(window.BedrockLabNative)window.BedrockLabNative.recordDownloadMeta(da.href,title,image);}
                            var a=e.target.closest('a[href]');
                            if(a){var c2=a.closest('.card');if(c2)record(a);}
                          },true);
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(script, null)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                    val popup = WebView(this@MainActivity)
                    popup.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, request: android.webkit.WebResourceRequest): Boolean {
                            val link = request.url
                            if (link.scheme == "https") web.loadUrl(link.toString())
                            else try { startActivity(Intent(Intent.ACTION_VIEW, link)) } catch (_: Exception) { }
                            popup.post { popup.destroy() }
                            return true
                        }
                    }
                    (resultMsg.obj as WebView.WebViewTransport).webView = popup
                    resultMsg.sendToTarget()
                    return true
                }
            }
            settings.setSupportMultipleWindows(true)
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(url, userAgent, contentDisposition, mimeType)
            })
        }
        downloadsPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(8))
            setBackgroundColor(dark)
        }
        downloadsPage.addView(TextView(this).apply {
            text = "Tus descargas"; textSize = 26f; setTextColor(pale)
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(6), 0, dp(4))
        })
        downloadsPage.addView(TextView(this).apply {
            text = "Guarda, comparte o importa tus packs descargados."
            textSize = 14f; setTextColor(Color.rgb(172, 188, 167)); setPadding(0, 0, 0, dp(12))
        })
        emptyDownloads = TextView(this).apply {
            text = "Aún no hay descargas. Busca un pack en el catálogo y toca su enlace de descarga."
            textSize = 15f; setTextColor(pale); setPadding(dp(16), dp(18), dp(16), dp(18)); setBackgroundColor(panel)
        }
        downloadList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val downloadScroll = ScrollView(this).apply { addView(downloadList) }
        downloadsPage.addView(emptyDownloads)
        downloadsPage.addView(downloadScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(19, 28, 18))
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        catalogTab = navButton("Catálogo", R.drawable.ic_catalog_globe) { showCatalog() }
        downloadsTab = navButton("Descargas", R.drawable.ic_download_arrow) { showDownloads() }
        tabs.addView(catalogTab, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(14); marginEnd = dp(14) })
        tabs.addView(downloadsTab, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(14); marginEnd = dp(14) })
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        offlinePage = buildOfflinePage()
        root.addView(offlinePage, LinearLayout.LayoutParams(-1, 0, 1f))
        offlinePage.visibility = View.GONE
        root.addView(downloadsPage, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(tabs, LinearLayout.LayoutParams(-1, dp(56)))
        setContentView(root)
        showCatalog()
    }

    private fun requestIsCatalog(url: String): Boolean = try {
        Uri.parse(url).host == "bedrock-lab-memeviod.onrender.com"
    } catch (_: Exception) { false }

    private fun transitionTo(show: View, hideA: View, hideB: View) {
        listOf(hideA, hideB).forEach { it.animate().cancel(); it.visibility = View.GONE }
        show.animate().cancel()
        show.alpha = 0f
        show.translationY = dp(10).toFloat()
        show.visibility = View.VISIBLE
        show.animate().alpha(1f).translationY(0f).setDuration(190).start()
    }

    private fun buildOfflinePage(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(28), dp(24), dp(28), dp(28))
        setBackgroundColor(dark)
        addView(TextView(this@MainActivity).apply {
            text = "Sin conexión por ahora"; textSize = 23f; setTextColor(pale)
            setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        })
        addView(TextView(this@MainActivity).apply {
            text = "Revisa tu conexión. Si el servidor está despertando, espera un momento y vuelve a intentar."
            textSize = 15f; setTextColor(Color.rgb(172,188,167)); gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(16))
        })
        addView(Button(this@MainActivity).apply {
            text = "Reintentar"; isAllCaps = false
            setOnClickListener { if (isNetworkAvailable()) { transitionTo(web, this@MainActivity.offlinePage, downloadsPage); web.reload() } else Toast.makeText(this@MainActivity, "No parece haber conexión a internet.", Toast.LENGTH_SHORT).show() }
        })
    }

    private fun navButton(label: String, iconRes: Int, action: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val icon = ImageView(this@MainActivity).apply {
            setImageResource(iconRes)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        }
        contentDescription = label
        addView(icon)
        tag = icon
        setOnClickListener { action() }
    }

    private fun styleTab(button: LinearLayout, selected: Boolean) {
        val icon = button.tag as ImageView
        val tint = if (selected) lime else Color.rgb(172, 188, 167)
        icon.setColorFilter(tint)
        button.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(if (selected) Color.rgb(47, 66, 40) else Color.TRANSPARENT)
            if (selected) setStroke(dp(1), Color.rgb(83, 112, 62))
        }
        button.alpha = if (selected) 1f else .72f
        if (selected) button.animate().scaleX(1.04f).scaleY(1.04f).setDuration(160).start()
        else button.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun showCatalog() {
        showingDownloads = false
        web.visibility = View.VISIBLE
        downloadsPage.visibility = View.GONE
        styleTab(catalogTab, true)
        styleTab(downloadsTab, false)
        transitionTo(web, offlinePage, downloadsPage)
    }

    private fun showDownloads() {
        showingDownloads = true
        styleTab(catalogTab, false)
        styleTab(downloadsTab, true)
        transitionTo(downloadsPage, web, offlinePage)
        updateDownloads()
    }

    private val downloadMetaBridge = object {
        @JavascriptInterface
        fun recordDownloadMeta(url: String, title: String, image: String) {
            val host = try { Uri.parse(url).host.orEmpty() } catch (_: Exception) { "" }
            if (host.isBlank()) return
            pendingPackTitle = title.take(180)
            pendingPackImage = image.take(1500)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_PENDING_TITLE, pendingPackTitle)
                .putString(KEY_PENDING_IMAGE, pendingPackImage)
                .apply()
        }
    }

    private fun enqueueDownload(url: String, userAgent: String, disposition: String?, mime: String?) {
        try {
            val uri = Uri.parse(url)
            val filename = filenameFrom(disposition, uri)
            val storedName = UUID.randomUUID().toString() + "-" + filename
            val request = DownloadManager.Request(uri)
                .setTitle(filename)
                .setDescription("Descarga de Bedrock Lab")
                .setMimeType(mime ?: "application/octet-stream")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "Bedrock Lab/$storedName")
            if (userAgent.isNotBlank()) request.addRequestHeader("User-Agent", userAgent)
            val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            val ids = tracked()
            ids.add(id)
            saveTracked(ids)
            val preferences = getSharedPreferences(PREFS, MODE_PRIVATE)
            val savedTitle = preferences.getString(KEY_PENDING_TITLE, "").orEmpty()
            val savedImage = preferences.getString(KEY_PENDING_IMAGE, "").orEmpty()
            preferences.edit()
                .putString("file_$id", storedName)
                .putString("title_$id", savedTitle.ifBlank { filename.substringBeforeLast('.', filename) })
                .putString("image_$id", savedImage)
                .putString("url_$id", url)
                .putString("agent_$id", userAgent)
                .putString("disposition_$id", disposition.orEmpty())
                .putString("mime_$id", mime.orEmpty())
                .remove(KEY_PENDING_TITLE)
                .remove(KEY_PENDING_IMAGE)
                .apply()
            pendingPackTitle = ""
            pendingPackImage = ""
            Toast.makeText(this, "Descarga iniciada. La encontrarás en Descargas.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar la descarga: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun filenameFrom(disposition: String?, uri: Uri): String {
        val raw = disposition?.let { Regex("filename\\*?=(?:UTF-8''|\\\")?([^;\\\"]+)", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
            ?: uri.lastPathSegment?.substringAfterLast('/')
            ?: "bedrock-pack"
        val decoded = try { URLDecoder.decode(raw.trim().trim('"'), "UTF-8") } catch (_: Exception) { raw }
        val safe = decoded.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ ()-]"), "_")
        return if (safe.contains('.')) safe else "$safe.bin"
    }

    private fun tracked(): MutableSet<Long> = getSharedPreferences(PREFS, MODE_PRIVATE)
        .getStringSet(KEY_IDS, emptySet())!!.mapNotNull { it.toLongOrNull() }.toMutableSet()

    private fun saveTracked(ids: Set<Long>) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(KEY_IDS, ids.map { it.toString() }.toSet()).apply()
    }

    private data class DownloadRow(val id: Long, val title: String, val displayTitle: String, val imageUrl: String, val status: Int, val reason: Int, val bytes: Long, val total: Long)
    private data class DownloadRowViews(val card: LinearLayout, val status: TextView, val progress: ProgressBar, val actions: LinearLayout)

    private fun readRows(): List<DownloadRow> {
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val ids = tracked()
        val rows = mutableListOf<DownloadRow>()
        val finished = mutableSetOf<Long>()
        ids.forEach { id ->
            try {
                manager.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        val stored = getSharedPreferences(PREFS, MODE_PRIVATE)
                        val fileTitle = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Archivo descargado"
                        rows.add(DownloadRow(id,
                            fileTitle,
                            stored.getString("title_$id", null).takeUnless { it.isNullOrBlank() } ?: fileTitle,
                            stored.getString("image_$id", "").orEmpty(),
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))))
                    } else finished.add(id)
                }
            } catch (_: Exception) { finished.add(id) }
        }
        if (finished.isNotEmpty()) { ids.removeAll(finished); saveTracked(ids) }
        return rows.sortedByDescending { it.id }
    }

    private fun updateDownloads() {
        val rows = readRows()
        val present = rows.map { it.id }.toSet()
        rowViews.keys.filter { it !in present }.forEach { id ->
            rowViews.remove(id)?.let { downloadList.removeView(it.card) }
        }
        emptyDownloads.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        rows.forEach { row ->
            val views = rowViews[row.id] ?: createDownloadRow(row).also {
                rowViews[row.id] = it
                downloadList.addView(it.card, 0, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
            }
            updateDownloadRow(row, views)
        }
    }

    private fun createDownloadRow(row: DownloadRow): DownloadRowViews {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(panel) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setImageResource(R.mipmap.ic_launcher_round)
            contentDescription = "Imagen de ${row.displayTitle}"
            background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(45,61,42)); cornerRadius = dp(13).toFloat() }
            clipToOutline = true; tag = row.imageUrl
        }
        top.addView(image, LinearLayout.LayoutParams(dp(76), dp(76)).apply { marginEnd = dp(14) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        info.addView(TextView(this).apply { text = row.displayTitle; textSize = 16f; setTextColor(pale); setTypeface(null, android.graphics.Typeface.BOLD); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
        val status = TextView(this).apply { textSize = 13f; setPadding(0, dp(6), 0, 0); maxLines = 2; setTextColor(Color.LTGRAY) }
        info.addView(status)
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        outer.addView(top)
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(lime); visibility = View.GONE }
        outer.addView(progress, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(10) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, dp(8), 0, 0) }
        outer.addView(actions)
        if (row.imageUrl.isNotBlank()) loadThumbnail(row.imageUrl, image)
        return DownloadRowViews(outer,status,progress,actions)
    }

    private fun updateDownloadRow(row: DownloadRow, views: DownloadRowViews) {
        val complete = row.status == DownloadManager.STATUS_SUCCESSFUL
        val failed = row.status == DownloadManager.STATUS_FAILED
        val paused = row.status == DownloadManager.STATUS_PAUSED
        val label = when {
            complete -> "Listo · ${formatSize(row.bytes)}"
            failed -> "Falló: ${downloadError(row.reason)}"
            paused -> "Pausada · ${downloadError(row.reason)}"
            row.total > 0 -> "Descargando · ${formatSize(row.bytes)} de ${formatSize(row.total)}"
            else -> "Descargando…"
        }
        views.status.text = if (complete) "$label · elige Importar, Guardar o Compartir" else label
        views.status.setTextColor(if (complete) lime else if (failed) Color.rgb(255,170,140) else Color.LTGRAY)
        views.progress.visibility = if (!complete && !failed && row.total > 0) View.VISIBLE else View.GONE
        if (row.total > 0) views.progress.progress = ((row.bytes * 100L / row.total).coerceIn(0,100)).toInt()
        val expected = if (failed) listOf("Reintentar","Eliminar") else if (complete) listOf("Importar","Guardar","Compartir") else listOf("Cancelar")
        val existing = (0 until views.actions.childCount).map { (views.actions.getChildAt(it) as? Button)?.text?.toString().orEmpty() }
        if (existing != expected) {
            views.actions.removeAllViews()
            expected.forEach { action ->
                val b = AppCompatButton(this).apply {
                    text = action
                    isAllCaps = false
                    textSize = 11f
                    minHeight = dp(38)
                    minimumHeight = dp(38)
                    setPadding(dp(5), 0, dp(5), 0)
                    setTextColor(pale)
                    backgroundTintList = null
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(if (action == "Importar" || action == "Guardar") lime else Color.rgb(47, 66, 40))
                        setStroke(dp(1), lime)
                        cornerRadius = dp(12).toFloat()
                    }
                    if (action == "Importar" || action == "Guardar") {
                        setTextColor(dark)
                    }
                    foreground = android.graphics.drawable.RippleDrawable(
                        android.content.res.ColorStateList.valueOf(Color.argb(42, 255, 255, 255)),
                        null,
                        android.graphics.drawable.GradientDrawable().apply {
                            setColor(Color.WHITE)
                            cornerRadius = dp(12).toFloat()
                        }
                    )
                }
                b.setOnClickListener {
                    when(action){
                        "Importar" -> openWithAndroid(row.id,row.title)
                        "Guardar" -> chooseSaveLocation(row.id,row.title)
                        "Compartir" -> shareDownload(row.id,row.title)
                        "Reintentar" -> retryDownload(row.id)
                        "Eliminar","Cancelar" -> removeDownload(row.id)
                    }
                }
                views.actions.addView(b,LinearLayout.LayoutParams(0,dp(42),1f).apply { marginStart=dp(3);marginEnd=dp(3) })
            }
        }
    }

    private fun downloadError(reason: Int): String = when(reason) {
        DownloadManager.ERROR_CANNOT_RESUME -> "no se pudo continuar"
        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "no se encuentra el destino"
        DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "el archivo ya existe"
        DownloadManager.ERROR_FILE_ERROR -> "error al guardar el archivo"
        DownloadManager.ERROR_HTTP_DATA_ERROR -> "error de conexión"
        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "no hay espacio suficiente"
        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "demasiadas redirecciones"
        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "el servidor rechazó la descarga"
        DownloadManager.ERROR_UNKNOWN -> "error desconocido"
        DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "esperando Wi-Fi"
        DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "esperando conexión"
        else -> "código $reason"
    }

    private fun chooseSaveLocation(id: Long, filename: String) {
        pendingSaveId=id
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream"
            putExtra(Intent.EXTRA_TITLE,filename)
        }
        startActivityForResult(intent,REQUEST_SAVE)
    }

    private fun shareDownload(id: Long, filename: String) {
        try {
            val uri=downloadUri(id)
            val intent=Intent(Intent.ACTION_SEND).apply {
                type=mimeFor(filename);putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newUri(contentResolver,filename,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent,"Compartir pack"))
        } catch(e:Exception) { Toast.makeText(this,"No se pudo compartir: ${e.localizedMessage}",Toast.LENGTH_LONG).show() }
    }

    private fun downloadUri(id:Long):Uri {
        val storedName=getSharedPreferences(PREFS,MODE_PRIVATE).getString("file_$id",null)?:error("No se encontró la ruta del archivo")
        val file=File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Bedrock Lab/$storedName")
        if(!file.isFile)error("No se encuentra el archivo descargado")
        return FileProvider.getUriForFile(this,"$packageName.files",file)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=REQUEST_SAVE)return
        val id=pendingSaveId;pendingSaveId=null
        if(resultCode!=RESULT_OK||data?.data==null||id==null)return
        try {
            val source=downloadUri(id)
            contentResolver.openInputStream(source).use { input ->
                contentResolver.openOutputStream(data.data!!).use { output ->
                    if(input==null||output==null)error("No se pudo guardar el archivo")
                    input.copyTo(output)
                }
            }
            Toast.makeText(this,"Pack guardado en el lugar que elegiste.",Toast.LENGTH_LONG).show()
        } catch(e:Exception) { Toast.makeText(this,"No se pudo guardar: ${e.localizedMessage}",Toast.LENGTH_LONG).show() }
    }

    private fun retryDownload(id:Long) {
        val p=getSharedPreferences(PREFS,MODE_PRIVATE)
        val url=p.getString("url_$id",null)
        if(url.isNullOrBlank()){Toast.makeText(this,"No guardé el enlace de esta descarga; elimínala y vuelve a bajarla desde su ficha.",Toast.LENGTH_LONG).show();return}
        pendingPackTitle=p.getString("title_$id","").orEmpty()
        pendingPackImage=p.getString("image_$id","").orEmpty()
        val agent=p.getString("agent_$id","").orEmpty()
        val disposition=p.getString("disposition_$id","").orEmpty()
        val mime=p.getString("mime_$id","").orEmpty()
        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        getSharedPreferences(PREFS,MODE_PRIVATE).getString("file_$id",null)?.let { stored ->
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Bedrock Lab/$stored").delete()
        }
        tracked().also{it.remove(id);saveTracked(it)}
        p.edit().putString(KEY_PENDING_TITLE,pendingPackTitle).putString(KEY_PENDING_IMAGE,pendingPackImage)
            .remove("file_$id").remove("title_$id").remove("image_$id").remove("url_$id").remove("agent_$id").remove("disposition_$id").remove("mime_$id").apply()
        enqueueDownload(url,agent,disposition,mime)
        updateDownloads()
    }

    private fun isNetworkAvailable():Boolean {
        val cm=getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network=cm.activeNetwork?:return false
        return cm.getNetworkCapabilities(network)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)==true
    }

    private fun openWithAndroid(id: Long, filename: String) {
        try {
            val uri = downloadUri(id)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeFor(filename))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Importar con…"))
        } catch (_: android.content.ActivityNotFoundException) {
            AlertDialog.Builder(this).setTitle("No aparece una app compatible")
                .setMessage("Android no encontró Minecraft ni otra app registrada para importar este formato. Puedes guardar el pack en Descargas del dispositivo y abrirlo desde un administrador de archivos o desde el juego.")
                .setPositiveButton("Guardar en el dispositivo") { _, _ -> chooseSaveLocation(id,filename) }
                .setNegativeButton("Entendido",null).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun mimeFor(filename: String): String = when (filename.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "mcpack", "mcaddon", "mcworld", "mctemplate", "zip" -> "application/octet-stream"
        else -> "application/octet-stream"
    }

    private fun removeDownload(id: Long) {
        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        getSharedPreferences(PREFS,MODE_PRIVATE).getString("file_$id",null)?.let { stored ->
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Bedrock Lab/$stored").delete()
        }
        tracked().also { it.remove(id); saveTracked(it) }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .remove("file_$id").remove("title_$id").remove("image_$id").remove("url_$id")
            .remove("agent_$id").remove("disposition_$id").remove("mime_$id").apply()
        rowViews.remove(id)?.let { downloadList.removeView(it.card) }
        updateDownloads()
    }

    private fun loadThumbnail(url: String, target: ImageView) {
        imageCache.get(url)?.let { target.setImageBitmap(it); return }
        imageExecutor.execute {
            try {
                val sourceHost = Uri.parse(url).host.orEmpty()
                val connection = URL(url).openConnection().apply {
                    connectTimeout = 10000
                    readTimeout = 12000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                    if (sourceHost.isNotBlank()) setRequestProperty("Referer", "https://$sourceHost/")
                }
                val bitmap = connection.getInputStream().use { BitmapFactory.decodeStream(it) } ?: return@execute
                imageCache.put(url, bitmap)
                runOnUiThread { if (target.isAttachedToWindow) target.setImageBitmap(bitmap) }
            } catch (_: Exception) { }
        }
    }

    private fun formatSize(n: Long): String = if (n < 1024) "$n B" else if (n < 1024 * 1024) "%.1f KB".format(n / 1024.0) else "%.1f MB".format(n / (1024.0 * 1024.0))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        if (showingDownloads) showCatalog() else if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        imageExecutor.shutdownNow()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val HOME = "https://bedrock-lab-memeviod.onrender.com/"
        private const val PREFS = "bedrock_lab_downloads"
        private const val KEY_IDS = "download_ids"
        private const val KEY_PENDING_TITLE = "pending_pack_title"
        private const val KEY_PENDING_IMAGE = "pending_pack_image"
        private const val REQUEST_SAVE = 3104
    }
}
