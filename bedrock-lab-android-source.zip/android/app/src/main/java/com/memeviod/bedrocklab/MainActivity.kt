package com.memeviod.bedrocklab

import android.app.DownloadManager
import android.os.Message
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.URLDecoder
import java.util.Locale
import java.net.URL
import java.util.concurrent.Executors
import android.util.LruCache

class MainActivity : AppCompatActivity() {
    private val dark = Color.rgb(16, 23, 15)
    private val panel = Color.rgb(26, 38, 26)
    private val lime = Color.rgb(185, 244, 107)
    private val pale = Color.rgb(244, 248, 239)
    private lateinit var web: WebView
    private lateinit var downloadsPage: LinearLayout
    private lateinit var catalogTab: LinearLayout
    private lateinit var downloadsTab: LinearLayout
    private var showingDownloads = false
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val imageCache = LruCache<String, Bitmap>(10 * 1024 * 1024)
    private var pendingPackTitle = ""
    private var pendingPackImage = ""
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            if (showingDownloads) renderDownloads()
            handler.postDelayed(this, 1800)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        pendingPackTitle = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PENDING_TITLE, "").orEmpty()
        pendingPackImage = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PENDING_IMAGE, "").orEmpty()
        buildUi()
        web.loadUrl(HOME)
        handler.post(refreshTask)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
        }
        web = WebView(this).apply {
            // Install before the first navigation: Android exposes JS bridges on the next document load.
            // This bridge only stores the selected catalogue item's title and thumbnail URL.
            addJavascriptInterface(downloadMetaBridge, "BedrockLabNative")
            setBackgroundColor(dark)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.userAgentString = settings.userAgentString + " BedrockLabAndroid/1.0"
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                    val host = Uri.parse(url).host.orEmpty()
                    super.onPageStarted(view, url, favicon)
                }

                override fun onPageFinished(view: WebView, url: String) {
                    if (Uri.parse(url).host != "bedrock-lab-memeviod.onrender.com") return
                    val script = """
                        (function(){
                          if(window.__bedrockDownloadMetaInstalled)return;
                          window.__bedrockDownloadMetaInstalled=true;
                          function record(a){
                            try {
                              var card=a.closest('.card'), title='', image='';
                              if(card){title=(card.querySelector('h3')||{}).innerText||''; image=(card.querySelector('img')||{}).src||'';}
                              if(!title){title=(document.querySelector('#detailTitle')||{}).innerText||document.title||'';}
                              if(window.BedrockLabNative)window.BedrockLabNative.recordDownloadMeta(a.href,title,image);
                            }catch(e){}
                          }
                          document.addEventListener('click',function(e){
                            var detail=e.target.closest('[data-detail]');
                            if(detail){var c=detail.closest('.card');if(c){var a=c.querySelector('a[href]');if(a)record(a);}}
                            var a=e.target.closest('a[href]');
                            if(a){var c2=a.closest('.card');if(c2)record(a);}
                          },true);
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(script, null)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                    val popup = WebView(this@MainActivity)
                    popup.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, request: android.webkit.WebResourceRequest): Boolean {
                            val link = request.url
                            if (link.scheme == "https") web.loadUrl(link.toString())
                            else try { startActivity(Intent(Intent.ACTION_VIEW, link)) } catch (_: Exception) { }
                            popup.post { popup.destroy() }
                            return true
                        }
                    }
                    (resultMsg.obj as WebView.WebViewTransport).webView = popup
                    resultMsg.sendToTarget()
                    return true
                }
            }
            settings.setSupportMultipleWindows(true)
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                enqueueDownload(url, userAgent, contentDisposition, mimeType)
            })
        }
        downloadsPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(20))
            setBackgroundColor(dark)
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(19, 28, 18))
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        catalogTab = navButton("Catálogo", R.drawable.ic_catalog_globe) { showCatalog() }
        downloadsTab = navButton("Descargas", R.drawable.ic_download_arrow) { showDownloads() }
        tabs.addView(catalogTab, LinearLayout.LayoutParams(0, dp(56), 1f))
        tabs.addView(downloadsTab, LinearLayout.LayoutParams(0, dp(56), 1f))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(downloadsPage, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(tabs, LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(root)
        showCatalog()
    }

    private fun navButton(label: String, iconRes: Int, action: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(16).toFloat()
        }
        val icon = ImageView(this@MainActivity).apply {
            setImageResource(iconRes)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = LinearLayout.LayoutParams(dp(25), dp(25))
        }
        contentDescription = label
        addView(icon)
        tag = icon
        setOnClickListener { action() }
    }

    private fun styleTab(button: LinearLayout, selected: Boolean) {
        val icon = button.tag as ImageView
        val tint = if (selected) lime else Color.rgb(172, 188, 167)
        icon.setColorFilter(tint)
        button.setBackgroundColor(Color.TRANSPARENT)
        button.alpha = if (selected) 1f else .78f
    }

    private fun showCatalog() {
        showingDownloads = false
        web.visibility = View.VISIBLE
        downloadsPage.visibility = View.GONE
        styleTab(catalogTab, true)
        styleTab(downloadsTab, false)
    }

    private fun showDownloads() {
        showingDownloads = true
        web.visibility = View.GONE
        downloadsPage.visibility = View.VISIBLE
        styleTab(catalogTab, false)
        styleTab(downloadsTab, true)
        renderDownloads()
    }

    private val downloadMetaBridge = object {
        @JavascriptInterface
        fun recordDownloadMeta(url: String, title: String, image: String) {
            val host = try { Uri.parse(url).host.orEmpty() } catch (_: Exception) { "" }
            if (host.isBlank()) return
            pendingPackTitle = title.take(180)
            pendingPackImage = image.take(1500)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_PENDING_TITLE, pendingPackTitle)
                .putString(KEY_PENDING_IMAGE, pendingPackImage)
                .apply()
        }
    }

    private fun enqueueDownload(url: String, userAgent: String, disposition: String?, mime: String?) {
        try {
            val uri = Uri.parse(url)
            val filename = filenameFrom(disposition, uri)
            val storedName = UUID.randomUUID().toString() + "-" + filename
            val request = DownloadManager.Request(uri)
                .setTitle(filename)
                .setDescription("Descarga de Bedrock Lab")
                .setMimeType(mime ?: "application/octet-stream")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "Bedrock Lab/$storedName")
            if (userAgent.isNotBlank()) request.addRequestHeader("User-Agent", userAgent)
            val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            val ids = tracked()
            ids.add(id)
            saveTracked(ids)
            val preferences = getSharedPreferences(PREFS, MODE_PRIVATE)
            val savedTitle = preferences.getString(KEY_PENDING_TITLE, "").orEmpty()
            val savedImage = preferences.getString(KEY_PENDING_IMAGE, "").orEmpty()
            preferences.edit()
                .putString("file_$id", storedName)
                .putString("title_$id", savedTitle.ifBlank { filename.substringBeforeLast('.', filename) })
                .putString("image_$id", savedImage)
                .remove(KEY_PENDING_TITLE)
                .remove(KEY_PENDING_IMAGE)
                .apply()
            pendingPackTitle = ""
            pendingPackImage = ""
            Toast.makeText(this, "Descarga iniciada. La encontrarás en Descargas.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar la descarga: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun filenameFrom(disposition: String?, uri: Uri): String {
        val raw = disposition?.let { Regex("filename\\*?=(?:UTF-8''|\\\")?([^;\\\"]+)", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
            ?: uri.lastPathSegment?.substringAfterLast('/')
            ?: "bedrock-pack"
        val decoded = try { URLDecoder.decode(raw.trim().trim('"'), "UTF-8") } catch (_: Exception) { raw }
        val safe = decoded.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ ()-]"), "_")
        return if (safe.contains('.')) safe else "$safe.bin"
    }

    private fun tracked(): MutableSet<Long> = getSharedPreferences(PREFS, MODE_PRIVATE)
        .getStringSet(KEY_IDS, emptySet())!!.mapNotNull { it.toLongOrNull() }.toMutableSet()

    private fun saveTracked(ids: Set<Long>) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putStringSet(KEY_IDS, ids.map { it.toString() }.toSet()).apply()
    }

    private data class DownloadRow(val id: Long, val title: String, val displayTitle: String, val imageUrl: String, val status: Int, val bytes: Long, val total: Long)

    private fun readRows(): List<DownloadRow> {
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val ids = tracked()
        val rows = mutableListOf<DownloadRow>()
        val finished = mutableSetOf<Long>()
        ids.forEach { id ->
            try {
                manager.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        val stored = getSharedPreferences(PREFS, MODE_PRIVATE)
                        val fileTitle = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Archivo descargado"
                        rows.add(DownloadRow(id,
                            fileTitle,
                            stored.getString("title_$id", null).takeUnless { it.isNullOrBlank() } ?: fileTitle,
                            stored.getString("image_$id", "").orEmpty(),
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))))
                    } else finished.add(id)
                }
            } catch (_: Exception) { finished.add(id) }
        }
        if (finished.isNotEmpty()) { ids.removeAll(finished); saveTracked(ids) }
        return rows.sortedByDescending { it.id }
    }

    private fun renderDownloads() {
        downloadsPage.removeAllViews()
        downloadsPage.addView(TextView(this).apply {
            text = "Tus descargas"
            textSize = 26f
            setTextColor(pale)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(4))
        })
        downloadsPage.addView(TextView(this).apply {
            text = "Toca un archivo terminado para elegir con qué aplicación abrirlo."
            textSize = 14f
            setTextColor(Color.rgb(172, 188, 167))
            setPadding(0, 0, 0, dp(14))
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val rows = readRows()
        if (rows.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Aún no hay descargas. Busca un pack en el catálogo y toca su enlace de descarga."
                textSize = 15f
                setTextColor(pale)
                setPadding(dp(16), dp(18), dp(16), dp(18))
                setBackgroundColor(panel)
            })
        }
        rows.forEach { row ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setBackgroundColor(panel)
            }
            val thumbnail = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(45, 61, 42))
                setImageResource(R.mipmap.ic_launcher_round)
                contentDescription = "Imagen de ${row.displayTitle}"
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(45, 61, 42))
                    cornerRadius = dp(13).toFloat()
                }
                clipToOutline = true
            }
            card.addView(thumbnail, LinearLayout.LayoutParams(dp(76), dp(76)).apply { marginEnd = dp(14) })
            val textBlock = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
            }
            textBlock.addView(TextView(this).apply {
                text = row.displayTitle
                textSize = 16f
                setTextColor(pale)
                setTypeface(null, android.graphics.Typeface.BOLD)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val complete = row.status == DownloadManager.STATUS_SUCCESSFUL
            val statusText = when (row.status) {
                DownloadManager.STATUS_SUCCESSFUL -> "Listo · ${formatSize(row.bytes)} · Toca para importar"
                DownloadManager.STATUS_FAILED -> "Falló la descarga · toca para quitarla"
                DownloadManager.STATUS_PAUSED -> "Descarga pausada"
                else -> if (row.total > 0) "Descargando · ${formatSize(row.bytes)} de ${formatSize(row.total)}" else "Descargando…"
            }
            textBlock.addView(TextView(this).apply {
                text = statusText
                textSize = 13f
                setTextColor(if (complete) lime else Color.LTGRAY)
                setPadding(0, dp(6), 0, 0)
                maxLines = 2
            })
            card.addView(textBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (row.imageUrl.isNotBlank()) loadThumbnail(row.imageUrl, thumbnail)
            if (complete) card.setOnClickListener { openWithAndroid(row.id, row.title) }
            else if (row.status == DownloadManager.STATUS_FAILED) card.setOnClickListener { removeDownload(row.id) }
            list.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
        }
        scroll.addView(list)
        downloadsPage.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun openWithAndroid(id: Long, filename: String) {
        try {
            val storedName = getSharedPreferences(PREFS, MODE_PRIVATE).getString("file_$id", null)
                ?: throw IllegalStateException("No se encontró la ruta del archivo")
            val file = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Bedrock Lab/$storedName")
            if (!file.isFile) throw IllegalStateException("No se encuentra el archivo descargado")
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeFor(filename))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Importar con…"))
        } catch (_: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "No hay una aplicación instalada que Android reconozca para abrir este archivo.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun mimeFor(filename: String): String = when (filename.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "mcpack", "mcaddon", "mcworld", "mctemplate", "zip" -> "application/octet-stream"
        else -> "application/octet-stream"
    }

    private fun removeDownload(id: Long) {
        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).remove(id)
        tracked().also { it.remove(id); saveTracked(it) }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .remove("file_$id").remove("title_$id").remove("image_$id").apply()
        renderDownloads()
    }

    private fun loadThumbnail(url: String, target: ImageView) {
        imageCache.get(url)?.let { target.setImageBitmap(it); return }
        imageExecutor.execute {
            try {
                val sourceHost = Uri.parse(url).host.orEmpty()
                val connection = URL(url).openConnection().apply {
                    connectTimeout = 10000
                    readTimeout = 12000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                    if (sourceHost.isNotBlank()) setRequestProperty("Referer", "https://$sourceHost/")
                }
                val bitmap = connection.getInputStream().use { BitmapFactory.decodeStream(it) } ?: return@execute
                imageCache.put(url, bitmap)
                runOnUiThread { if (target.isAttachedToWindow) target.setImageBitmap(bitmap) }
            } catch (_: Exception) { }
        }
    }

    private fun formatSize(n: Long): String = if (n < 1024) "$n B" else if (n < 1024 * 1024) "%.1f KB".format(n / 1024.0) else "%.1f MB".format(n / (1024.0 * 1024.0))
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        if (showingDownloads) showCatalog() else if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    companion object {
        private const val HOME = "https://bedrock-lab-memeviod.onrender.com/"
        private const val PREFS = "bedrock_lab_downloads"
        private const val KEY_IDS = "download_ids"
        private const val KEY_PENDING_TITLE = "pending_pack_title"
        private const val KEY_PENDING_IMAGE = "pending_pack_image"
    }
}
